# Genbank plasmid maps of IFN reporter plasmids

The reporters are:

 - [1517_pHAGE2_IFNbeta_prom_LNGFR_P2A_mNeongreen.gb](1517_pHAGE2_IFNbeta_prom_LNGFR_P2A_mNeongreen.gb)
 - [1767_pHAGE2_IL29_promnkozak_LNGFR_P2A_zsGreen.gb](1767_pHAGE2_IL29_promnkozak_LNGFR_P2A_zsGreen.gb)
